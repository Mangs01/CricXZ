param([string]$ProjectRoot = "D:\Projects\CricXZ")
$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item "$PackageRoot\..\articles\india-west-indies-first-odi-2026.html" "$ProjectRoot\articles\india-west-indies-first-odi-2026.html" -Force
Write-Host "Locked CricXZ article HTML installed successfully." -ForegroundColor Green
Write-Host "This replaces only the article HTML; existing CSS is preserved." -ForegroundColor Green
