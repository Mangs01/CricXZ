param(
    [string]$ProjectRoot = "D:\Projects\CricXZ"
)

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ArticleSlug = "india-west-indies-first-odi-2026"

New-Item -ItemType Directory -Force -Path "$ProjectRoot\articles" | Out-Null
New-Item -ItemType Directory -Force -Path "$ProjectRoot\assets\images\articles" | Out-Null

Copy-Item "$PackageRoot\..\articles\$ArticleSlug.html" "$ProjectRoot\articles\$ArticleSlug.html" -Force
Copy-Item "$PackageRoot\..\assets\images\articles\$ArticleSlug-cricxz.webp" "$ProjectRoot\assets\images\articles\$ArticleSlug-cricxz.webp" -Force

# Add sitemap URL only if it does not already exist.
$sitemap = "$ProjectRoot\sitemap.xml"
if (Test-Path $sitemap) {
    $xml = Get-Content $sitemap -Raw
    $url = "https://cricxz.com/articles/$ArticleSlug.html"
    if ($xml -notmatch [regex]::Escape($url)) {
        $entry = "  <url><loc>$url</loc><lastmod>2026-09-28</lastmod></url>`r`n"
        $xml = $xml -replace "</urlset>", ($entry + "</urlset>")
        Set-Content $sitemap $xml -Encoding UTF8
    }
}

# Add search-data item before the final array close when the project uses the expected array format.
$search = "$ProjectRoot\assets\js\search-data.js"
if (Test-Path $search) {
    $js = Get-Content $search -Raw
    $url = "articles/$ArticleSlug.html"
    if ($js -notmatch [regex]::Escape($url)) {
        $item = @"
  {
    title: "India Beat West Indies by 8 Wickets as Kohli, Gill Shine in 1st ODI",
    url: "$url",
    type: "article",
    category: "ODI"
  },
"@
        $last = $js.LastIndexOf("]")
        if ($last -ge 0) {
            $js = $js.Insert($last, $item)
            Set-Content $search $js -Encoding UTF8
        }
    }
}

Write-Host ""
Write-Host "CricXZ India vs West Indies 1st ODI article installed successfully." -ForegroundColor Green
Write-Host "Updated: article, hero image, sitemap and search data (where matching structure was found)." -ForegroundColor Green
