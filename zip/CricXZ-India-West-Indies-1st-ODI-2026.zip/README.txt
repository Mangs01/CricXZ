# CricXZ Article Package

Article: India Beat West Indies by 8 Wickets as Kohli, Gill Shine in 1st ODI
Slug: india-west-indies-first-odi-2026

Files:
- articles/india-west-indies-first-odi-2026.html
- assets/images/articles/india-west-indies-first-odi-2026-cricxz.webp
- tools/india-west-indies-first-odi-2026.json
- tools/install-india-west-indies-first-odi-2026.ps1

Install from PowerShell:
Expand-Archive ...   # If converted to ZIP
powershell -ExecutionPolicy Bypass -File ".\tools\install-india-west-indies-first-odi-2026.ps1" -ProjectRoot "D:\Projects\CricXZ"

Then:
cd D:\Projects\CricXZ
git status
git add .
git commit -m "Add India West Indies first ODI match report"
git push
