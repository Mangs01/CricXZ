param(
  [Parameter(Mandatory=$true)][string]$ProjectRoot
)
$ErrorActionPreference = 'Stop'
$ProjectRoot = (Resolve-Path $ProjectRoot).Path
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $ProjectRoot (".cricxz-backup\india-west-indies-second-odi-final-$stamp")
New-Item -ItemType Directory -Path $backup -Force | Out-Null

$files = @(
  'articles\india-west-indies-second-odi-2026.html',
  'assets\images\articles\india-west-indies-second-odi-2026-cricxz.webp',
  'pages\news.html',
  'index.html',
  'assets\js\search-data.js',
  'sitemap.xml'
)
foreach ($rel in $files) {
  $src = Join-Path $ProjectRoot $rel
  if (Test-Path $src) {
    $dst = Join-Path $backup ($rel -replace '\\','__')
    Copy-Item $src $dst -Force
  }
}

$pkg = Split-Path -Parent $MyInvocation.MyCommand.Path
Copy-Item (Join-Path $pkg 'articles\india-west-indies-second-odi-2026.html') (Join-Path $ProjectRoot 'articles\india-west-indies-second-odi-2026.html') -Force
Copy-Item (Join-Path $pkg 'assets\images\articles\india-west-indies-second-odi-2026-cricxz.webp') (Join-Path $ProjectRoot 'assets\images\articles\india-west-indies-second-odi-2026-cricxz.webp') -Force

function Replace-Regex([string]$Path,[string]$Pattern,[string]$Replacement) {
  $text = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
  $new = [regex]::Replace($text,$Pattern,$Replacement,[System.Text.RegularExpressions.RegexOptions]::Singleline)
  if ($new -eq $text) { throw "Pattern not found in $Path" }
  Set-Content -LiteralPath $Path -Value $new -Encoding UTF8
}

# News page: replace the existing first card for this exact URL.
$newsCard = @'
<a href="../articles/india-west-indies-second-odi-2026.html" class="news-card" data-category="india odi">
  <img src="../assets/images/articles/india-west-indies-second-odi-2026-cricxz.webp" alt="CricXZ match graphic for India beat West Indies by 8 wickets in the second ODI">
  <div class="news-content">
    <span class="news-tag">India vs West Indies 2026 • 2nd ODI</span>
    <h3>India Beat West Indies by 8 Wickets in 2nd ODI as Shubman Gill Smashes Double Century</h3>
    <p>Gill smashed 223* after reaching his second ODI double century in 117 balls as India chased 406 in 43.3 overs.</p>
    <span class="read-more">Read More &rarr;</span>
  </div>
</a>
'@
Replace-Regex (Join-Path $ProjectRoot 'pages\news.html') '<a href="\.\./articles/india-west-indies-second-odi-2026\.html"[\s\S]*?</a>\s*(?=<a href="\.\./articles/india-west-indies-first-odi-2026\.html")' ($newsCard + "")

# Homepage: update the existing featured card, preserving its position.
$homeCard = @'
<div class="news-card">
  <img src="assets/images/articles/india-west-indies-second-odi-2026-cricxz.webp" alt="CricXZ match graphic for India beat West Indies by 8 wickets in the second ODI">
  <h3>India Beat West Indies by 8 Wickets in 2nd ODI as Shubman Gill Smashes Double Century</h3>
  <p>Gill finished unbeaten on 223 as India chased 406 in 43.3 overs and took a 2-0 series lead.</p>
  <a href="articles/india-west-indies-second-odi-2026.html">Read More &rarr;</a>
</div>
'@
Replace-Regex (Join-Path $ProjectRoot 'index.html') '<div class="news-card">\s*<img src="assets/images/articles/india-west-indies-second-odi-2026-cricxz\.webp"[\s\S]*?</div>\s*(?=<div class="news-card">\s*<img src="assets/images/articles/india-west-indies-first-odi-2026-cricxz\.webp")' ($homeCard + "")

# Search index: insert/replace one entry inside the maintained article block.
$search = Join-Path $ProjectRoot 'assets\js\search-data.js'
$searchText = Get-Content $search -Raw -Encoding UTF8
$searchText = [regex]::Replace($searchText,'\{\s*title:\s*"India Beat West Indies by 8 Wickets in 2nd ODI as Shubman Gill Smashes Double Century",\s*type:\s*"News",\s*url:\s*"articles/india-west-indies-second-odi-2026\.html"\s*\},\s*','',[Text.RegularExpressions.RegexOptions]::Singleline)
$entry = @'
{
    title: "India Beat West Indies by 8 Wickets in 2nd ODI as Shubman Gill Smashes Double Century",
    type: "News",
    url: "articles/india-west-indies-second-odi-2026.html"
},
'@
$marker = '    // CRICXZ:NEWS-ARTICLES:START'
if ($searchText -notmatch [regex]::Escape($marker)) { throw 'Search article marker not found.' }
$searchText = $searchText.Replace($marker, $marker + "`r`n" + $entry)
Set-Content $search -Value $searchText -Encoding UTF8

# Sitemap: remove any old URL entry and add the final report URL at the top of the article block.
$sitemap = Join-Path $ProjectRoot 'sitemap.xml'
$smap = Get-Content $sitemap -Raw -Encoding UTF8
$smap = [regex]::Replace($smap,'\s*<url>\s*<loc>https://cricxz\.com/articles/india-west-indies-second-odi-2026\.html</loc>[\s\S]*?</url>','',[Text.RegularExpressions.RegexOptions]::Singleline)
$smapEntry = @'
<url>
  <loc>https://cricxz.com/articles/india-west-indies-second-odi-2026.html</loc>
  <lastmod>2026-09-30</lastmod>
</url>
'@
$marker2 = '    <!-- CRICXZ:ARTICLE-URLS:START -->'
if ($smap -notmatch [regex]::Escape($marker2)) { throw 'Sitemap article marker not found.' }
$smap = $smap.Replace($marker2, $marker2 + "`r`n" + $smapEntry)
Set-Content $sitemap -Value $smap -Encoding UTF8

Write-Host ''
Write-Host 'CricXZ India vs West Indies 2nd ODI FINAL report installed successfully.' -ForegroundColor Green
Write-Host 'Updated: article, hero image, homepage card, news card, search data and sitemap.'
Write-Host "Backup: $backup"
Write-Host 'URL unchanged: articles/india-west-indies-second-odi-2026.html'
