CRICXZ — INDIA vs WEST INDIES 2nd ODI FINAL REPORT

This package replaces the existing preview article at the SAME URL.

Target URL:
articles/india-west-indies-second-odi-2026.html

Included:
- Final match-report HTML
- New 1536x1024 CricXZ hero image
- PowerShell installer
- Homepage/news/search/sitemap integration

Install:
1. Extract this ZIP.
2. Open PowerShell.
3. Run:
   powershell -ExecutionPolicy Bypass -File ".\install-india-west-indies-second-odi-final.ps1" -ProjectRoot "D:\Projects\CricXZ"

The installer creates a timestamped backup under .cricxz-backup before changing existing files.
